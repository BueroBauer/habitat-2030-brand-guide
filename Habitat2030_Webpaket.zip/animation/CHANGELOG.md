# Habitat 2030 Intro: Einbau

Basis: bestehendes Markup `.intro` (h1, .line-container, .line, h1.right, .claim). Kein neues HTML.
Werte aus Seite: --black #111, --background #C9C1B4, --line-stroke-width 0.5rem, --gap 1.75rem, Schrift neue-haas-grotesk-display (Typekit acy3ijw).

1. `intro-addon.css` ans Ende von `css/app.css`.
2. In `js/app.js`: alte `initIntroAnimation()` löschen, Inhalt von `intro.js` (beide Funktionen) einfügen. Den Aufruf `initIntroAnimation()` im bestehenden DOMContentLoaded-Block entfernen, `intro.js` hat einen eigenen Listener.
3. Im `<head>` (header.php), damit nichts aufblitzt: `<script>document.documentElement.classList.add('js-intro')</script>`
4. Test: `preview.html` über lokalen Server öffnen (python3 -m http.server).

Ablauf (ca. 3,5 s): Habitat 2030 in einer Zeile, Text fährt auseinander + Linie wächst, Texte wechseln auf y, Linie dreht in Diagonale, Randlinien wachsen, Claim blendet ein. Danach übernimmt der bestehende Scroll-Effekt.
prefers-reduced-motion: Intro entfällt, Seite startet im Endzustand.
Noch offen: Intro bei jedem Besuch oder nur einmal pro Sitzung.

## Responsive (Adapt)
- Breakpoint wie Theme: max-width 767.98px = mobil.
- Mobil: Diagonale = Diagonale des Feldes zwischen den Randlinien, ragt nie über den Viewport (vorher Querscroll).
- Scroll-Effekt startet bei scrollY 0 (vorher `top center-=200`, dort war die Linie beim Laden schon halb gedreht, Sprung nach dem Intro).
- Gap Text zu Linie max. 25 % des freien Platzes, "2030" wird nie abgeschnitten.
- Mobil Intro ca. 15 % straffer. Resize oder Drehen während des Intros springt direkt in den Endzustand.
- Geprüft: 375 und 1512 px, kein Querscroll. Nicht geprüft: Tablet-Hochformat, 320 px, echtes Gerät.

## Fix Claim/Button + Einblenden
- Ursache: Intro setzte `y` auf `.claim`, GSAP überschrieb damit das CSS `transform: translateY(-100%)` (Desktop). Claim saß zu tief. Jetzt nur Opacity, Transform bleibt von der Seite.
- Gemessen Desktop 1512: Claim top 689, Button 25/729 identisch zur Live-Seite.
- Start: Wort blendet 0,9 s sanft ein (0 auf 1 gemessen), danach 0,25 s Pause, dann Auseinanderfahren. Claim blendet am Ende per Opacity ein.

## Fix Linienende
- Ursache: `start: 0` im Scroll-Effekt war falsch. Auf der Live-Seite steht der Scrub beim Laden schon bei ca. 45 % (Winkel ca. 15°, Breite 1328 px), nicht bei der vollen Diagonale. Intro endete dadurch in anderer Länge und Winkel.
- Jetzt: originaler `start: "top center-=200"`. Das Intro liest den Zustand der Seite per Probe-Tween und läuft exakt darauf zu.
- Gemessen Desktop 1512: Linien-Box Preview = Live (106/217/1391/571).

## Fix Mobil abgeschnitten / überlappend
- Ursache: Mobil ist "Habitat 2030" in einer Zeile fast so breit wie der Viewport. Das Auseinanderfahren hatte keinen Platz (375 px: Linie nur ca. 8 px lang, 320 px: Wörter überlappten).
- Mobil (max 767.98px): Startzeile wird bei Bedarf skaliert (Ursprung linke Textkante), kein Auseinanderfahren. Linie entsteht, während die Wörter auf der y-Achse wechseln und auf Normalgröße skalieren. Desktop unverändert.
- Fade-in: 1,8 s, power2.inOut. scrollbar-gutter stable während des Intros.
- Geprüft per Screenshots: 320 und 375 px, Start, Mitte, Ende. Nicht geprüft: echtes Gerät, Querformat, Tablet.

## Vorlage = Live-Seite (Klarstellung)
- Mobil-Sonderfall in `lineGeometry` entfernt: Endzustand mobil jetzt identisch zur Live-Seite (375 px: Linie -3/191/366/250, Claim oben 611, Button 646).
- Desktop 1512: Linie 106/217, Claim 689, Button 729, identisch zu Live.
- Live-Seite selbst: mobil ragt die Linie 3 px links über den Viewport. Kommt aus dem Theme, nicht aus dem Intro.

## Mobil-Layout nach Vorlage (Bild vom 2026-11-11)
- `intro-addon.css`: mobil (max 767.98px) füllt das Intro den Viewport (100svh), Grid: Habitat oben, Linienfeld in der Mitte, Claim + Button unten links, 2030 unten rechts. Randlinien 16 % Höhe, Linienfeld 2rem Abstand zur Headline.
- `intro.js`: Scroll-Start mobil `top top` statt `top center-=200`, damit die Diagonale bei scrollY 0 voll steht und nicht über den Rand ragt.
- Texte bleiben die der Live-Seite ("Bauen gegen die Klimakrise!", "Mach mit"). Desktop unverändert.
- Geprüft: 375x635 (Start, Mitte, Ende) gegen Vorlage. Nicht geprüft: 320 px mit neuem Layout, Querformat, Tablet, echtes Gerät.

## Resize / Responsive-Fix
- Ursache: Länge und Winkel der Linie wurden nur einmal beim Laden berechnet, danach stimmten sie nach Resize nicht mehr. Der Resize-Handler griff nur, solange die Timeline aktiv war.
- Jetzt: Scroll-Effekt mit Funktionswerten + `invalidateOnRefresh`, Resize-Handler global. Läuft das Intro noch, wird es beendet und springt in den Endzustand. Danach rechnet ScrollTrigger neu.
- Geprüft: 1512 auf 1000 nach dem Intro = identisch zu frischem Load bei 1000. Desktop auf 375 mitten im Intro und zurück auf 1100: Endzustand korrekt, Overflow frei.
- Nicht geprüft: echtes Gerät drehen, Browser-Zoom.
