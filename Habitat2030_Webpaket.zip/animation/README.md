# Habitat 2030: Intro-Animation, Übergabe

Intro für die Startseite (WordPress-Theme `habitat2030`). Die Animation baut auf dem bestehenden Markup der Startseite auf. Es gibt kein neues HTML.

Ablauf (ca. 4,5 s Desktop, ca. 3,9 s mobil):
1. "Habitat 2030" steht in einer Zeile und blendet sanft ein (1,8 s).
2. Der Text fährt auseinander, die Linie entsteht dazwischen (nur Desktop).
3. Die Texte wechseln auf der y-Achse, die Linie dreht in die Diagonale.
4. Die Randlinien wachsen, der Claim blendet ein.

Danach übernimmt der bestehende Scroll-Effekt der Linie. Der Endzustand entspricht der bisherigen Startseite. Mobil (bis 767,98 px) gilt ein eigenes Layout: Intro füllt den Viewport, Claim und Button unten links, "2030" unten rechts.

## Dateien

| Datei | Zweck |
|---|---|
| `intro.js` | Logik, ersetzt `initIntroAnimation()` in `js/app.js` |
| `intro-addon.css` | Ergänzung für `css/app.css` |
| `preview.html` | Teststand, lädt CSS, JS und Schrift von der Dev-Seite |
| `INFO-PROGRAMMIERER.md` | Kurze Infoliste für die Umsetzung |
| `CHANGELOG.md` | Protokoll aller Fehler und Fixes während der Entwicklung |

## Einbau

1. `intro-addon.css` ans Ende von `wp-content/themes/habitat2030/css/app.css` kopieren.
2. In `js/app.js`:
   - die alte Funktion `initIntroAnimation()` löschen,
   - den Aufruf `initIntroAnimation();` im bestehenden `DOMContentLoaded`-Block löschen,
   - den Inhalt von `intro.js` einfügen oder als eigene Datei nach `app.js` einbinden. Die Datei registriert ihren eigenen Start, sonst läuft das Intro doppelt.
3. Im `<head>` (header.php) möglichst weit oben einfügen, damit nichts aufblitzt:
   `<script>document.documentElement.classList.add('js-intro');setTimeout(function(){document.documentElement.classList.remove('js-intro')},7000)</script>`
4. Cache leeren, Versionsparameter von `app.css` und `app.js` hochzählen (`?v=1.2` auf `?v=1.3`).

Voraussetzungen im Theme (vorhanden): gsap und ScrollTrigger (laden vor `app.js`), Typekit-Schrift `neue-haas-grotesk-display`.

## Was sich auf der Live-Seite ändert

- Der Scroll-Effekt der Linie startet mobil bei `top top` statt `top center-=200`, damit die Diagonale nicht über den Rand ragt. Desktop bleibt `top center-=200`.
- Länge und Winkel der Linie werden bei jedem Resize neu berechnet (`invalidateOnRefresh`). Die alte Version rechnete nur einmal beim Laden und ging nach einem Resize falsch.
- Mobil hat die Startseite jetzt das Grid-Layout (100svh).

## Verhalten

- `prefers-reduced-motion: reduce`: kein Intro, Seite startet im Endzustand.
- Resize oder Drehen während des Intros: Das Intro bricht ab und springt in den Endzustand. Danach rechnet ScrollTrigger neu. Das ist Absicht, weil die Maße nicht mehr passen.
- Während des Intros ist das Scrollen gesperrt (`overflow: hidden`, `scrollbar-gutter: stable`). Das Sperren endet automatisch am Ende des Intros.
- Das Intro läuft bei jedem Seitenaufruf (entschieden).

## Gemessene Referenzwerte (Desktop 1512×956, Endzustand)

Linien-Box links/oben/rechts/unten: 106 / 217 / 1391 / 571. Claim oben 689, Button oben 729. Intro und bisherige Live-Seite sind identisch.

Mobil gilt das neue Grid-Layout. Es wurde per Screenshot gegen das Zielbild geprüft, nicht gegen Live-Werte, weil es sich bewusst vom alten Layout unterscheidet.

## Bekannte Risiken, bitte testen

- Nicht geprüft: Safari und Firefox, echte Geräte, Gerät drehen, Browser-Zoom, Windows-Scrollbars, Tablet-Hochformat, 320 px mit neuem Mobil-Layout.
- Fällt gsap oder `intro.js` aus, entfernt das Inline-Script die Klasse `js-intro` nach 7 s, Überschriften und Claim werden dann sichtbar. Dieser Fallback ist nicht getestet.
- Randlinien mobil (`top: 42%; bottom: 42%`) wurden nach Augenmaß aus dem Zielbild geschätzt. Bei sehr niedrigen Viewports wird das Linienfeld klein.
- Der Link im Claim zeigt auf `habitat2030.local/mitmachen/` statt auf die Live-Domain. Das stammt aus dem Seiteninhalt, nicht aus dem Intro.

## Testen

`preview.html` über einen lokalen Server öffnen, zum Beispiel im Ordner `python3 -m http.server 8765`, dann `http://localhost:8765/preview.html`. Direkt per `file://` geht es nicht in allen Browsern. Zum Prüfen das Fenster ziehen und mobil mit den DevTools testen.
