# Info für den Programmierer: Habitat 2030 Intro

## Auftrag
Intro-Animation für die Startseite https://habitat2030.cle.sc/. Läuft bei jedem Seitenaufruf (entschieden, kein sessionStorage nötig).

## Einbau, kurz
1. `intro-addon.css` ans Ende von `css/app.css`.
2. `js/app.js`: alte `initIntroAnimation()` und ihren Aufruf löschen, Inhalt von `intro.js` einfügen oder nach `app.js` einbinden.
3. `header.php`, möglichst weit oben im `<head>`: `<script>document.documentElement.classList.add('js-intro');setTimeout(function(){document.documentElement.classList.remove('js-intro')},7000)</script>`
4. Versionsparameter `app.css` und `app.js` hochzählen, Cache leeren.

## Wichtig
- Kein neues HTML. Die Animation nutzt `.intro h1`, `.line-container`, `.line`, `.claim`.
- Das Intro startet sich selbst. Bleibt der alte Aufruf in `app.js`, läuft es doppelt.
- gsap und ScrollTrigger müssen vor dem Script laden (im Theme vorhanden).
- Schrift `neue-haas-grotesk-display` (Typekit) muss geladen sein, das Script wartet auf `document.fonts.ready`.
- Breakpoint mobil: `max-width: 767.98px`, wie im Theme.

## Änderungen an der bestehenden Seite
- Scroll-Effekt der Linie: Länge und Winkel werden bei jedem Resize neu berechnet.
- Mobil startet der Scroll-Effekt bei `top top` (Desktop unverändert `top center-=200`).
- Mobil neues Layout: Intro 100svh, Habitat oben, Claim und Button unten links, 2030 unten rechts.

## Verhalten
- `prefers-reduced-motion`: kein Intro, Endzustand sofort.
- Resize oder Drehen während des Intros: Abbruch, Sprung in den Endzustand.
- Scroll während des Intros gesperrt, endet automatisch.

## Bitte testen
- Safari, Firefox, iOS, Android (nicht geprüft)
- Gerät drehen, Browser-Zoom, Windows-Scrollbar
- Tablet hochkant, 320 px mit neuem Mobil-Layout
- Ausfall von gsap: Fallback im Inline-Script entfernt `js-intro` nach 7 s (ungetestet, bitte prüfen).

## Offen, nicht Teil des Intros
- Link im Claim zeigt auf `habitat2030.local/mitmachen/` statt auf die Live-Domain.
- Randlinien mobil (`top/bottom: 42%`) nach Augenmaß aus dem Zielbild, ggf. nachziehen.

## Dateien
`intro.js`, `intro-addon.css`, `preview.html` (Teststand, lokal per `python3 -m http.server`), `README.md` (Details), `CHANGELOG.md` (Fehlerprotokoll).
